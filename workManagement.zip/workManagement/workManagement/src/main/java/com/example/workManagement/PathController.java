package com.example.workManagement;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@Controller
public class PathController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private Work work = new Work();

    @Autowired
    private User user = new User();


    @GetMapping("/")
    public String index(Model model){
        return "index";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam("userid") String user_id,
            @RequestParam("password") String password,
            Model model
    ) {
        Boolean isAuth = user.Login(user_id, password);

        if(isAuth) {
            model.addAttribute("user_id", user_id);
            return "/mainmenu";
        } else {
            model.addAttribute("loginError", "ログインIDまたはパスワードが間違っています。");
            return "index";
        }
    }

    @GetMapping("/mainmenu")
    public String mainmenu(
            Model model
    ){
        return "mainmenu";
    }

    @GetMapping("/menu/attendance_in")
    public String indeattendance_inx(Model model){
        return "menu/attendance_in";
    }

    @GetMapping("/menu/workplace_regist")
    public String workplace_regist(Model model){
        return "menu/workplace_regist";
    }

    @GetMapping("/menu/contact_regist")
    public String contact_regist(Model model){
        return "menu/contact_regist";
    }

    @GetMapping("/menu/attendance_all_view")
    public String attendance_all_view(Model model){
        return "menu/attendance_all_view";
    }

    @GetMapping("/menu/attendance_history_view")
    public String attendance_history_view(Model model){

        //all workを実行
        List<Map<String,Object>> allwork = work.getAllAttendance();
        model.addAttribute("allWork",allwork);
        return "menu/attendance_history_view";
    }

    @GetMapping("/menu/logout")
    public String logout(Model model){
        return "menu/logout";
    }

    @GetMapping("/error")
    public String error(Model model){
        return "error";
    }


}
