package com.example.workManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private User user;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if(user.Login(username, "...")) {
            // ここでSpring SecurityのUserDetailsオブジェクトを返す。実際には役割や権限を適切に設定する必要がある。
            return new org.springframework.security.core.userdetails.User(username, "...", new ArrayList<>());
        } else {
            throw new UsernameNotFoundException("User not found");
        }
    }
}
