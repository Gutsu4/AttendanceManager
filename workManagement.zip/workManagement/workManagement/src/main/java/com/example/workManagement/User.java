package com.example.workManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.swing.tree.ExpandVetoException;

@Service
public class User {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public boolean Login(String user_id,String password){

        String sql = "SELECT password FROM users WHERE user_id = ?";

        try{
            String storedPassword = jdbcTemplate.queryForObject(sql,String.class,user_id);
            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
            return passwordEncoder.matches(password,storedPassword);

        }catch (Exception e){
            return false;
        }
    }

}
